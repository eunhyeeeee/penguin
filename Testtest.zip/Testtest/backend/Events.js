module.exports = [
  {
    id: 1,
    title: '은혜와 정만',
    detail: '여기 커먼힐즈 ~',
    date: '2020-09-02'
  },
  {
    id: 2,
    title: '이시내',
    detail: '이신애 아안녀어엉',
    date: '2020-09-02'
  },
  {
    id: 3,
    title: '김젠장',
    detail: '젠장쓰도 아녕 ~',
    date: '2020-09-02'
  }
];